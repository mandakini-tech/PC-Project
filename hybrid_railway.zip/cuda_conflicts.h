#pragma once
int compute_cuda_conflict_rows(const float* starts, const float* ends, int n,
                               const int* row_ids, int row_count, int* output);
