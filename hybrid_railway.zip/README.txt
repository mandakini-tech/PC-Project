HYBRID MPI + OPENMP + CUDA RAILWAY PLATFORM COLORING (REVISED)
============================================================

FILES
- hybrid_railway.cpp: MPI coordination, OpenMP CPU conflict work/validation,
  Greedy, Welsh-Powell, DSATUR, dynamic DSATUR repair, metrics
- cuda_conflicts.cu / cuda_conflicts.h: CUDA kernel for parallel conflict graph construction
- trains.csv: small SIMULATED train dataset
- events.csv: SIMULATED occupancy-time changes
- railway.ipynb: Google Colab notebook with compile and run commands

INPUT FORMAT
trains.csv columns:
  train_id,start,end,eligible_platforms[,clearance_minutes]
- Eligible platform IDs are separated by semicolons (example: 1;2;3).
- The optional fifth field is a nonnegative clearance duration in minutes. If omitted,
  clearance defaults to 0. The effective occupancy interval is [start, end + clearance).
- Times are simulated minutes in an arbitrary evaluation window.

events.csv columns:
  train_id,new_start,new_end
- Events replace a train's start/end times. The train's configured clearance remains applied.

MODEL AND ALGORITHMS
- One train service = one graph vertex.
- An edge connects trains whose effective occupancy intervals overlap.
- Platform eligibility is checked separately from graph conflicts.
- Initial allocations are compared using Greedy (input order), Welsh-Powell (descending
  graph degree), and DSATUR (highest saturation degree, then degree, then lower train index).
- For each schedule event, the code updates the graph and performs a local DSATUR repair,
  attempting to preserve unaffected assignments. It also measures a full DSATUR recomputation
  as a comparison. Both are heuristics and do not guarantee a globally optimal solution.

REPORTED METRICS
- Unassigned trains and accommodation rate
- Conflict violations and ineligible assignments
- Platform utilization, defined as the union of assigned effective occupancy intervals across
  platforms divided by (number of platform IDs * overall evaluation-window duration)
- Graph construction time, baseline coloring time, dynamic repair time, full recomputation time
- Number of changed platform assignments after each event

HYBRID RESPONSIBILITIES
- MPI distributes conflict-graph rows across ranks.
- MPI rank 0 attempts CUDA for its assigned rows.
- Other ranks use OpenMP to calculate their assigned rows; rank 0 falls back to OpenMP if CUDA
  is unavailable or fails.
- MPI_Reduce combines partial graph matrices on rank 0.
- OpenMP parallelizes conflict validation.

COMPILE (Ubuntu/WSL with CUDA Toolkit and OpenMPI installed)
  nvcc -O2 -c cuda_conflicts.cu -o cuda_conflicts.o
  mpicxx -O2 -std=c++17 -fopenmp -c hybrid_railway.cpp -o hybrid_railway.o
  mpicxx -fopenmp hybrid_railway.o cuda_conflicts.o -L/usr/local/cuda/lib64 -lcudart -o hybrid_railway

RUN
  OMP_NUM_THREADS=4 mpirun --oversubscribe -np 2 ./hybrid_railway trains.csv events.csv

To run only the initial allocation, omit events.csv:
  OMP_NUM_THREADS=4 mpirun --oversubscribe -np 2 ./hybrid_railway trains.csv

COLAB
- Open railway.ipynb, upload the revised ZIP, and run the cells in order.
- Actual CUDA use requires a compatible GPU and CUDA compiler/runtime. If CUDA is unavailable,
  the program falls back to OpenMP on rank 0 (MPI/OpenMP execution still requires MPI).

LIMITATIONS
- The provided train data and events are simulated, not an official Mumbai timetable.
- The simplified model includes interval overlap, platform eligibility, and optional clearance
  buffers; it does not model detailed track routing, crossing movements, signaling, or all
  station-specific operational rules.
- This is a research/decision-support prototype, not railway dispatching or signaling software.
- The adjacency matrix uses O(n^2) memory. Benchmark larger scenarios and repeat runs before
  drawing performance conclusions. MPI/GPU overhead may make hybrid execution slower on small data.
