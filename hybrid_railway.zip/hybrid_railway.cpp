#include <mpi.h>
#include <omp.h>
#include "cuda_conflicts.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;

// CSV: id,start,end,eligible_platforms[;...][,clearance_minutes]
// Times are simulated minutes. Clearance is added to the occupancy end.
struct Train { string id; double s=0, e=0, clearance=0; };
struct Event { int i; double s,e; };
enum class Algorithm { Greedy, WelshPowell, DSATUR };
const char* algorithmName(Algorithm a) {
    switch(a) { case Algorithm::Greedy: return "Greedy"; case Algorithm::WelshPowell: return "Welsh-Powell"; default: return "DSATUR"; }
}
vector<string> split(const string& x, char d) {
    vector<string> v; string a; stringstream ss(x);
    while(getline(ss,a,d)) v.push_back(a);
    return v;
}
vector<Train> loadTrains(const string& file, vector<int>& elig, int& n, int& pcount) {
    ifstream f(file); if(!f) throw runtime_error("Cannot open "+file);
    vector<Train> ts; vector<vector<int>> ps; string line; pcount=0;
    while(getline(f,line)) {
        if(line.empty() || line[0]=='#') continue;
        auto a=split(line,','); if(a.size()<4) continue;
        Train t; t.id=a[0]; t.s=stod(a[1]); t.e=stod(a[2]);
        if(t.e<t.s) throw runtime_error("end before start: "+t.id);
        if(a.size()>=5 && !a[4].empty()) t.clearance=stod(a[4]);
        if(t.clearance<0) throw runtime_error("clearance must be nonnegative: "+t.id);
        vector<int> ep;
        for(auto q:split(a[3],';')) if(!q.empty()) {
            int p=stoi(q); if(p<=0) throw runtime_error("platform IDs must be positive");
            if(find(ep.begin(),ep.end(),p-1)==ep.end()) ep.push_back(p-1);
            pcount=max(pcount,p);
        }
        if(ep.empty()) throw runtime_error("no eligible platforms: "+t.id);
        ts.push_back(t); ps.push_back(ep);
    }
    n=(int)ts.size(); elig.assign((size_t)n*pcount,0);
    for(int i=0;i<n;i++) for(int p:ps[i]) elig[i*pcount+p]=1;
    return ts;
}
vector<Event> loadEvents(const string& file, const vector<Train>& ts) {
    vector<Event> ev; ifstream f(file); if(!f) return ev;
    string line;
    while(getline(f,line)) {
        if(line.empty()||line[0]=='#') continue;
        auto a=split(line,','); if(a.size()<3) continue;
        int idx=-1; for(int i=0;i<(int)ts.size();i++) if(ts[i].id==a[0]) {idx=i;break;}
        if(idx<0) throw runtime_error("unknown train in events: "+a[0]);
        double s=stod(a[1]),e=stod(a[2]); if(e<s) throw runtime_error("event end before start");
        ev.push_back({idx,s,e});
    }
    return ev;
}
void broadcastData(vector<Train>& ts, vector<int>& elig, int& n, int& pcount, int rank) {
    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD); MPI_Bcast(&pcount,1,MPI_INT,0,MPI_COMM_WORLD);
    vector<double> times((size_t)3*n); vector<char> names((size_t)n*64,'\0');
    if(rank==0) for(int i=0;i<n;i++) {
        times[3*i]=ts[i].s; times[3*i+1]=ts[i].e; times[3*i+2]=ts[i].clearance;
        string id=ts[i].id.substr(0,63); copy(id.begin(),id.end(),names.begin()+i*64);
    } else { ts.resize(n); elig.resize((size_t)n*pcount); }
    MPI_Bcast(times.data(),3*n,MPI_DOUBLE,0,MPI_COMM_WORLD); MPI_Bcast(names.data(),n*64,MPI_CHAR,0,MPI_COMM_WORLD);
    MPI_Bcast(elig.data(),n*pcount,MPI_INT,0,MPI_COMM_WORLD);
    for(int i=0;i<n;i++) { ts[i].s=times[3*i]; ts[i].e=times[3*i+1]; ts[i].clearance=times[3*i+2];
        if(rank!=0) ts[i].id=string(&names[i*64],strnlen(&names[i*64],64)); }
}
vector<int> makeGraph(const vector<Train>& ts,int rank,int world,bool& cudaUsed) {
    int n=(int)ts.size(); vector<int> local((size_t)n*n,0), rows; vector<float> s(n),e(n);
    for(int i=0;i<n;i++){s[i]=(float)ts[i].s;e[i]=(float)(ts[i].e+ts[i].clearance);}
    for(int i=rank;i<n;i+=world) rows.push_back(i);
    bool didCuda=false;
    if(rank==0 && !rows.empty()) {
        vector<int> compact((size_t)rows.size()*n);
        if(compute_cuda_conflict_rows(s.data(),e.data(),n,rows.data(),(int)rows.size(),compact.data())) {
            didCuda=true; for(int r=0;r<(int)rows.size();r++) copy(compact.begin()+r*n,compact.begin()+(r+1)*n,local.begin()+(size_t)rows[r]*n);
        } else {
            #pragma omp parallel for schedule(static)
            for(int r=0;r<(int)rows.size();r++){int i=rows[r];for(int j=0;j<n;j++)local[(size_t)i*n+j]=(i!=j&&max(ts[i].s,ts[j].s)<min(ts[i].e+ts[i].clearance,ts[j].e+ts[j].clearance));}
        }
    } else {
        #pragma omp parallel for schedule(static)
        for(int r=0;r<(int)rows.size();r++){int i=rows[r];for(int j=0;j<n;j++)local[(size_t)i*n+j]=(i!=j&&max(ts[i].s,ts[j].s)<min(ts[i].e+ts[i].clearance,ts[j].e+ts[j].clearance));}
    }
    vector<int> adj((size_t)n*n,0); MPI_Reduce(local.data(),adj.data(),n*n,MPI_INT,MPI_SUM,0,MPI_COMM_WORLD);
    int a=didCuda?1:0,b=0; MPI_Allreduce(&a,&b,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD); cudaUsed=(b==1); return adj;
}
int degreeOf(int i,const vector<int>& adj,int n){int d=0;for(int j=0;j<n;j++)d+=adj[(size_t)i*n+j]!=0;return d;}
int choosePlatform(int i,const vector<int>& adj,const vector<int>& elig,int pc,const vector<int>& c,int n) {
    vector<char> used(pc,0); for(int j=0;j<n;j++) if(adj[(size_t)i*n+j]&&c[j]>=0) used[c[j]]=1;
    for(int p=0;p<pc;p++) if(elig[(size_t)i*pc+p]&&!used[p]) return p; return -1;
}
vector<int> colorGraph(const vector<int>& adj,const vector<int>& elig,int pc,Algorithm alg,
                       const vector<int>* old=nullptr,int changed=-1) {
    int n=(int)sqrt((double)adj.size()); vector<int> c(n,-1); vector<char> affected(n,old?0:1);
    if(old && changed>=0) {
        affected[changed]=1; for(int j=0;j<n;j++) if(adj[(size_t)changed*n+j]) affected[j]=1;
        for(int i=0;i<n;i++) if(!affected[i]) {int p=(*old)[i];if(p>=0&&p<pc&&elig[(size_t)i*pc+p])c[i]=p;}
        // Any preserved assignment that became conflicting is released for recoloring.
        for(int i=0;i<n;i++) if(c[i]>=0) for(int j=0;j<i;j++) if(c[j]==c[i]&&adj[(size_t)i*n+j]) {c[i]=-1;affected[i]=1;break;}
    }
    vector<int> order; for(int i=0;i<n;i++) if(affected[i]) order.push_back(i);
    if(alg==Algorithm::WelshPowell) {
        stable_sort(order.begin(),order.end(),[&](int a,int b){int da=degreeOf(a,adj,n),db=degreeOf(b,adj,n);return da==db?a<b:da>db;});
    } else if(alg==Algorithm::DSATUR) {
        vector<int> candidates=order, sequence; vector<char> done(n,0);
        sequence.reserve(candidates.size());
        for(size_t step=0;step<candidates.size();step++) {
            int best=-1,bSat=-1,bDeg=-1;
            for(int i:candidates) if(!done[i]) {
                vector<char> seen(pc,0); int sat=0;
                for(int j=0;j<n;j++) if(adj[(size_t)i*n+j]&&c[j]>=0&&!seen[c[j]]){seen[c[j]]=1;sat++;}
                int deg=degreeOf(i,adj,n);
                if(sat>bSat||(sat==bSat&&(deg>bDeg||(deg==bDeg&&(best<0||i<best))))){best=i;bSat=sat;bDeg=deg;}
            }
            if(best>=0){done[best]=1;sequence.push_back(best);c[best]=choosePlatform(best,adj,elig,pc,c,n);}
        }
        return c;
    }
    for(int i:order) { if(c[i]>=0) continue; c[i]=choosePlatform(i,adj,elig,pc,c,n); }
    return c;
}
long long reassignmentCount(const vector<int>& before,const vector<int>& after) {
    long long count=0; for(size_t i=0;i<before.size()&&i<after.size();i++) if(before[i]!=after[i]) count++; return count;
}
double platformUtilization(const vector<Train>& ts,const vector<int>& c,int pc) {
    if(ts.empty()||pc<=0) return 0.0;
    double lo=ts[0].s,hi=ts[0].e+ts[0].clearance;
    for(const auto&t:ts){lo=min(lo,t.s);hi=max(hi,t.e+t.clearance);}
    if(hi<=lo) return 0.0;
    double occupied=0;
    for(int p=0;p<pc;p++) {
        vector<pair<double,double>> intervals;
        for(size_t i=0;i<ts.size();i++) if(c[i]==p) intervals.push_back({ts[i].s,ts[i].e+ts[i].clearance});
        sort(intervals.begin(),intervals.end());
        if(intervals.empty()) continue;
        double a=intervals[0].first,b=intervals[0].second;
        for(size_t k=1;k<intervals.size();k++) {if(intervals[k].first<=b)b=max(b,intervals[k].second);else{occupied+=max(0.0,b-a);a=intervals[k].first;b=intervals[k].second;}}
        occupied+=max(0.0,b-a);
    }
    return 100.0*occupied/(pc*(hi-lo));
}
void report(const vector<Train>& ts,const vector<int>& adj,const vector<int>& c,const vector<int>& elig,int pc,const string& title) {
    int n=(int)ts.size(),unassigned=0,badEligibility=0; long long conflicts=0;
    for(int i=0;i<n;i++){if(c[i]<0)unassigned++;else if(!elig[(size_t)i*pc+c[i]])badEligibility++;}
    #pragma omp parallel for reduction(+:conflicts) schedule(static)
    for(int i=0;i<n;i++) if(c[i]>=0) for(int j=i+1;j<n;j++) if(adj[(size_t)i*n+j]&&c[i]==c[j]) conflicts++;
    cout<<"\n=== "<<title<<" ===\nTrain\tEffective interval\tPlatform\n";
    for(int i=0;i<n;i++) cout<<ts[i].id<<"\t["<<ts[i].s<<","<<(ts[i].e+ts[i].clearance)<<")\t"<<(c[i]<0?string("UNASSIGNED"):to_string(c[i]+1))<<"\n";
    cout<<"Unassigned: "<<unassigned<<"/"<<n<<"\nAccommodation rate: "<<fixed<<setprecision(2)<<(n?100.0*(n-unassigned)/n:0)<<"%"
        <<"\nConflict violations: "<<conflicts<<"\nIneligible assignments: "<<badEligibility
        <<"\nPlatform utilization (union occupied time / total platform-window time): "<<platformUtilization(ts,c,pc)<<"%"
        <<"\nValidation: "<<((conflicts==0&&badEligibility==0)?"PASS":"FAIL")<<"\n";
}
int main(int argc,char** argv) {
    MPI_Init(&argc,&argv); int rank=0,world=1; MPI_Comm_rank(MPI_COMM_WORLD,&rank); MPI_Comm_size(MPI_COMM_WORLD,&world);
    string tf=argc>1?argv[1]:"trains.csv",ef=argc>2?argv[2]:"events.csv";
    vector<Train> ts; vector<int> elig; vector<Event> events; int n=0,pc=0;
    if(rank==0) try {ts=loadTrains(tf,elig,n,pc);if(!n||!pc)throw runtime_error("empty train input");events=loadEvents(ef,ts);}
    catch(const exception& x){cerr<<"Input error: "<<x.what()<<"\n";MPI_Abort(MPI_COMM_WORLD,1);}
    broadcastData(ts,elig,n,pc,rank);
    int ec=rank==0?(int)events.size():0; MPI_Bcast(&ec,1,MPI_INT,0,MPI_COMM_WORLD);
    vector<int> ei(ec);vector<double> et((size_t)2*ec);
    if(rank==0)for(int k=0;k<ec;k++){ei[k]=events[k].i;et[2*k]=events[k].s;et[2*k+1]=events[k].e;}
    if(ec){MPI_Bcast(ei.data(),ec,MPI_INT,0,MPI_COMM_WORLD);MPI_Bcast(et.data(),2*ec,MPI_DOUBLE,0,MPI_COMM_WORLD);}
    if(rank==0)cout<<"Hybrid MPI + OpenMP + CUDA | MPI ranks="<<world<<" | OpenMP max threads/rank="<<omp_get_max_threads()<<" | trains="<<n<<" | platforms="<<pc<<" | simulated events="<<ec<<"\n";

    double graphStart=MPI_Wtime(); bool gpu=false; vector<int> adj=makeGraph(ts,rank,world,gpu); double graphSeconds=MPI_Wtime()-graphStart;
    vector<int> current;
    if(rank==0) {
        cout<<"\nInitial graph construction time (seconds): "<<graphSeconds<<"\nCUDA used for graph construction: "<<(gpu?"yes":"no; OpenMP fallback")<<"\n";
        // Compare all three baselines on exactly the same graph and inputs.
        for(Algorithm a:{Algorithm::Greedy,Algorithm::WelshPowell,Algorithm::DSATUR}) {
            double t0=MPI_Wtime(); vector<int> result=colorGraph(adj,elig,pc,a); double sec=MPI_Wtime()-t0;
            report(ts,adj,result,elig,pc,string("Initial allocation - ")+algorithmName(a));
            cout<<"Coloring computation time ("<<algorithmName(a)<<", seconds): "<<sec<<"\n";
            if(a==Algorithm::DSATUR) current=result;
        }
    }
    for(int k=0;k<ec;k++) {
        int changed=ei[k]; ts[changed].s=et[2*k];ts[changed].e=et[2*k+1];
        double gs=MPI_Wtime(); bool eventGpu=false;vector<int> next=makeGraph(ts,rank,world,eventGpu);double gsec=MPI_Wtime()-gs;
        if(rank==0) {
            vector<int> previous=current;
            double rs=MPI_Wtime(); current=colorGraph(next,elig,pc,Algorithm::DSATUR,&previous,changed);double repairSec=MPI_Wtime()-rs;
            long long changes=reassignmentCount(previous,current);
            report(ts,next,current,elig,pc,"Dynamic DSATUR repair after update "+to_string(k+1)+" ("+ts[changed].id+")");
            cout<<"Changed assignments versus previous schedule: "<<changes<<"\nDynamic repair time (seconds): "<<repairSec<<"\nUpdated graph construction time (seconds): "<<gsec<<"\nCUDA used for updated graph: "<<(eventGpu?"yes":"no; OpenMP fallback")<<"\n";
            double fs=MPI_Wtime();vector<int> full=colorGraph(next,elig,pc,Algorithm::DSATUR);double fullSec=MPI_Wtime()-fs;
            cout<<"Full DSATUR recomputation time (seconds): "<<fullSec<<"\nFull recomputation assignment changes versus previous schedule: "<<reassignmentCount(previous,full)<<"\n";
        }
        adj.swap(next);
    }
    if(rank==0) cout<<"\nRun finished. (Use the per-stage timings above for graph/coloring/repair comparisons.)\n";
    MPI_Finalize();return 0;
}
