#include "cuda_conflicts.h"
#include <cuda_runtime.h>

__global__ void conflictKernel(const float* s, const float* e, const int* rows,
                               int n, int rowCount, int* out) {
    int k = blockIdx.x * blockDim.x + threadIdx.x;
    if (k >= rowCount * n) return;
    int r = k / n, j = k % n, i = rows[r];
    out[k] = (i != j && fmaxf(s[i], s[j]) < fminf(e[i], e[j])) ? 1 : 0;
}

int compute_cuda_conflict_rows(const float* s, const float* e, int n,
                               const int* rows, int rowCount, int* out) {
    int devices = 0;
    if (cudaGetDeviceCount(&devices) != cudaSuccess || devices == 0) {
        cudaGetLastError();
        return 0;
    }
    float *ds=nullptr, *de=nullptr;
    int *dr=nullptr, *dout=nullptr;
    size_t tb=(size_t)n*sizeof(float), rb=(size_t)rowCount*sizeof(int);
    size_t ob=(size_t)rowCount*n*sizeof(int);
    if (cudaMalloc(&ds,tb)!=cudaSuccess) goto fail;
    if (cudaMalloc(&de,tb)!=cudaSuccess) goto fail;
    if (cudaMalloc(&dr,rb)!=cudaSuccess) goto fail;
    if (cudaMalloc(&dout,ob)!=cudaSuccess) goto fail;
    if (cudaMemcpy(ds,s,tb,cudaMemcpyHostToDevice)!=cudaSuccess) goto fail;
    if (cudaMemcpy(de,e,tb,cudaMemcpyHostToDevice)!=cudaSuccess) goto fail;
    if (cudaMemcpy(dr,rows,rb,cudaMemcpyHostToDevice)!=cudaSuccess) goto fail;
    {
        int total=rowCount*n, threads=256, blocks=(total+threads-1)/threads;
        conflictKernel<<<blocks,threads>>>(ds,de,dr,n,rowCount,dout);
        if (cudaGetLastError()!=cudaSuccess || cudaDeviceSynchronize()!=cudaSuccess) goto fail;
        if (cudaMemcpy(out,dout,ob,cudaMemcpyDeviceToHost)!=cudaSuccess) goto fail;
    }
    cudaFree(ds); cudaFree(de); cudaFree(dr); cudaFree(dout);
    return 1;
fail:
    if(ds) cudaFree(ds); if(de) cudaFree(de); if(dr) cudaFree(dr); if(dout) cudaFree(dout);
    cudaGetLastError();
    return 0;
}
